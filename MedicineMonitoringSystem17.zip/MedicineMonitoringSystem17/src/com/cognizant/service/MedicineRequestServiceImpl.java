package com.cognizant.service;

import java.util.Hashtable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDAOImpl;
import com.cognizant.dao.MedicineRequestDAO;
import com.cognizant.entity.MedicineRequest;
import com.cognizant.model.MedicineRequestModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Service("MedicineRequestServiceImpl")

public class MedicineRequestServiceImpl implements MedicineRequestService{

	@Autowired
	private MedicineRequestDAO medicineRequestDAO;
	
	@Autowired
	private MedicineRequestModel medicineRequestModel;
	private static Logger logger=LoggerFactory.getLogger(MedicineRequestService.class);
	public boolean insertMedicineRequest(MedicineRequestModel medicinerequest) {
		// TODO Auto-generated method stub
		logger.info("----------INSERT MEDICINE SERVICE---------------");
		MedicineRequest medicineRequest=medicineRequestModel.medicineRequestModelToEntity(medicinerequest);
		
		return medicineRequestDAO.insertMedicineRequest(medicineRequest);
	}

	public List<MedicineRequestModel> getMedicineRequests() {
		// TODO Auto-generated method stub
                     logger.info("----------GET ALL MEDICINES SERVICE---------------");
		List<MedicineRequest> medicineRequest=medicineRequestDAO.getMedicineRequests();
		List<MedicineRequestModel> medicineRequestModelList=medicineRequestModel.medicineRequestEntityToModelList(medicineRequest);
		
		return medicineRequestModelList;
	}

	public boolean checkMedicineRequest(MedicineRequestModel medicineRequest) {
		// TODO Auto-generated method stub
	logger.info("----------CHECK MEDICINE QUNTITY  SERVICE---------------");
		Hashtable<Integer,Integer> hm=new Hashtable<Integer,Integer>();
		hm.put(medicineRequest.getMedicine5Id(), medicineRequest.getQuantity5());
		hm.put(medicineRequest.getMedicine4Id(), medicineRequest.getQuantity4());
		hm.put(medicineRequest.getMedicine3Id(), medicineRequest.getQuantity3());
		hm.put(medicineRequest.getMedicine2Id(), medicineRequest.getQuantity2());
		hm.put(medicineRequest.getMedicine1Id(), medicineRequest.getQuantity1());
		return medicineRequestDAO.checkMedicineRequest(hm);
	}

	public boolean updateBranchAdminRequest(MedicineRequestModel medicineRequest) {
		// TODO Auto-generated method stub
	logger.info("----------UPDATE MEDICINEREQUEST SERVICE---------------");
		MedicineRequest medicineRequestmodel=medicineRequestModel.medicineRequestModelToEntity(medicineRequest);
		
		return medicineRequestDAO.updateBranchAdminRequest(medicineRequestmodel);
	}

	public MedicineRequestModel fetchMedicineRequestInfo(int requestId) {
		// TODO Auto-generated method stub
	logger.info("----------GET MEDICINEREQUEST OBJECT SERVICE---------------");
		MedicineRequest medicineRequest=medicineRequestDAO.fetchMedicineRequestInfo(requestId);
		MedicineRequestModel medicineRequestmodel=medicineRequestModel.medicineRequestEntityToModel(medicineRequest);
		
		return medicineRequestmodel;
	}

	public List<String> getBranchAdminIds() {
		// TODO Auto-generated method stub
    logger.info("----------GETTING BRANCH ADMIN LIST IN MEDICINEREQUEST SERVICE---------------");
		return medicineRequestDAO.getBranchAdminIds();
	}

	public List<Integer> getMedicineIds() {
		// TODO Auto-generated method stub
	logger.info("----------GETTING MEDICINES ID IN  MEDICINEREQUEST SERVICE---------------");
		return medicineRequestDAO.getMedicineIds();
	}

	public int getRequestPendingCount() {
		// TODO Auto-generated method stub
	logger.info("----------GETTING  REQUEST PENDING COUNT IN MEDICINEREQUEST SERVICE---------------");
		return medicineRequestDAO.getRequestPendingCount();
	}

	

	@Override
	public List<MedicineRequestModel> getApprovedRequests() {
		// TODO Auto-generated method stub
		List<MedicineRequest> medicineRequest=medicineRequestDAO.getApprovedRequests();
		List<MedicineRequestModel> medicineRequestModelList=medicineRequestModel.medicineRequestEntityToModelList(medicineRequest);
		
		return medicineRequestModelList;
	}

	@Override
	public List<MedicineRequestModel> getRejectedRequests() {
		// TODO Auto-generated method stub
		List<MedicineRequest> medicineRequest=medicineRequestDAO.getRejectedRequests();
		List<MedicineRequestModel> medicineRequestModelList=medicineRequestModel.medicineRequestEntityToModelList(medicineRequest);
		
		return medicineRequestModelList;
	}

	

}
