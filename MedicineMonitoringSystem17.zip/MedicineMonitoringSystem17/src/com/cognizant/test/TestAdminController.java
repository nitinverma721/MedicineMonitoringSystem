package com.cognizant.test;

import static org.junit.Assert.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.controller.AdminController;
import com.cognizant.dao.AdminDAOImpl;
import com.cognizant.dao.MedicineDAO;
import com.cognizant.entity.Admin;
import com.cognizant.entity.BranchAdmin;
import com.cognizant.entity.Medicine;
import com.cognizant.entity.MedicineRequest;
import com.cognizant.helper.SessionCreator;
import com.cognizant.model.AdminModel;
import com.cognizant.model.BranchAdminModel;
import com.cognizant.service.AdminService;
import com.cognizant.service.AdminServiceImpl;
import com.cognizant.service.BranchAdminService;
import com.cognizant.service.MedicineRequestService;
import com.cognizant.service.MedicineService;
import com.cognizant.service.NotificationService;
import com.cognizant.validation.MedicineValidator;
import com.cognizant.validation.LoginValidator;
import com.cognizant.validation.RegisterValidator;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:/config/applicationContext.xml")
public class TestAdminController {

	private MockMvc mockMvc;
	
	
	@Mock
	private BranchAdminModel branchAdminModel;

	@Autowired
	@Mock
	private AdminDAOImpl adminDAOImpl;
	
	@Autowired
	@Mock
	private AdminService adminService;
	@Mock
	private Session session;
	
	 @Autowired
	 @Spy @Qualifier("LoginValidator")
	 private LoginValidator loginValidator; 
	
	 @Autowired @Qualifier("AddMedicineValidator")
	 @Mock
		private MedicineValidator addmedicineValidator;
		
		@Autowired
		@Spy
		private MedicineService medicineService;
	 
		@Autowired
		@Spy
		private BranchAdminService branchAdminService;
		
		@Autowired
		@Mock
		private MedicineRequestService medicineRequestService;
		
		@Autowired
		@Spy
		private AdminServiceImpl adminServiceimpl;

		
		@Autowired@Qualifier("RegisterValidator")
		@Spy
		private RegisterValidator registerValidator;
		
		@Autowired@Qualifier("BranchAdminValidator")
		@Mock
	   private Validator branchAdminValidator;
	 
	@Autowired
private SessionFactory sessionFactory;
	
	@Autowired
	@Mock
	private NotificationService notificationService;
	

		
	@InjectMocks
	private AdminController adminController;
	
	
	@Before
	public void setUp(){
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders
                .standaloneSetup(adminController)
                .build();
    
	}

	@After
	public void tearDown() throws Exception {
	
	}

	@Test
	public void testLoginAdmin() {
			AdminModel admin = new AdminModel();
			admin.setAdminId("2");
			admin.setAdminPassword("tree");
			MockHttpSession session=new MockHttpSession();
			
			MockHttpServletRequest request=new MockHttpServletRequest();
			MockHttpServletResponse response=new MockHttpServletResponse(); 
			Errors errors= new BeanPropertyBindingResult("1","com.cognizant.controller.wrongAdminId");
			
			ModelAndView mv=adminController.loginAdmin(admin,errors, session);
	    	String actual=mv.getViewName();
	    	String expected="branchadmin";
	    	assertEquals(expected,actual);
	    	}

	@Test
	public void testShowLogin() {
		
		String expected="adminlogin";
		String actual=adminController.showLogin();
		assertEquals(expected,actual);
	}


	

	@Test
	public void testRegisterAdmin() {
		AdminModel admin=new AdminModel();
		admin.setAdminFirstName("adminFname");
		admin.setAdminLastName("adminLastName");
		admin.setAdminEmailId("faltubaat@gmil.cm");
		admin.setAdminAge(21);
		admin.setAdminDOB("21/11/7895");
		admin.setAdminContactNo("45614589");
		admin.setAdminGender("M");
		admin.setAdminAltContactNo("891230200");
		admin.setAdminPassword("50820");
		
	
		
		System.out.println(admin.getAdminId());
		Errors errors= new BeanPropertyBindingResult("3","com.cognizant.controller.wrongAdminContactNo");
		
		ModelAndView mv=adminController.registerAdmin(admin,errors);
		String actual=mv.getViewName();
    	String expected="registersuccess";
		assertEquals(actual,expected);
	
	}
	
	
	
	
	@Test
	public void testShowBranchAdminHome() {
		
		MockHttpSession session=new MockHttpSession();
		MockHttpServletRequest request=new MockHttpServletRequest();
		request.setSession(session);
		session.setAttribute("adminId", "1");
		MockHttpServletResponse response=new MockHttpServletResponse(); 
		ModelAndView modelAndView= adminController.showBranchAdminHome(request);
		
		String result=modelAndView.getViewName();
		String expected="branchadmin";
		assertEquals(expected,result);	
		
	}
	
	

	@Test
	public void testShowCreateRequestMedicinepage() {
		try{
			MockHttpSession session=new MockHttpSession();
			MockHttpServletRequest request=new MockHttpServletRequest();
			request.setSession(session);
			session.setAttribute("adminId", "1");
			ModelMap map=new ModelMap();
			
			ModelAndView mv = adminController.showCreateRequestMedicinepage(request);

		String actual = mv.getViewName();
		String expected = "createrequest";
		assertEquals(actual,expected);
		}catch(Exception e){
			System.out.println(e);
		
		}
			
	}
	
	
	@Test
	public void testShowBranchAdminDetails() {
		ModelMap map=new ModelMap();
		MockHttpSession session=new MockHttpSession();
		
		MockHttpServletRequest request=new MockHttpServletRequest();
		MockHttpServletResponse response=new MockHttpServletResponse(); 
		request.setSession(session);
		session.setAttribute("adminId","1");
		Errors errors= new BeanPropertyBindingResult("3","com.cognizant.controller.wrongAdminContactNo");
		
		ModelAndView mv= adminController.showBranchAdminDetails("branch29",map,request);
		String expected="branchadmindetails";
		String actual=mv.getViewName();
		assertEquals(actual,expected);
		
	}
	
	
	
	@Test
	public void testCreateBranchAdmin() {
		
		try{
			BranchAdminModel branchAdminModel=new BranchAdminModel();
			Errors errors= new BeanPropertyBindingResult("1","com.cognizant.controller.wrongAdminId");
			branchAdminModel.setBranchAdminFirstName("sad");
			branchAdminModel.setBranchAdminLastName("mad");
			branchAdminModel.setBranchAdminAge(55);
			branchAdminModel.setBranchAdminGender("M");
			branchAdminModel.setBranchAdminDOB("45/8/12");
			branchAdminModel.setBranchAdminContactNo("80258963");
			branchAdminModel.setBranchAdminAltContactNo("152630879");
			branchAdminModel.setBranchAdminEmailId("admin@gmail.com");
			branchAdminModel.setBranchName("Bname");
			branchAdminModel.setAddressLine1("ALine1");
			branchAdminModel.setAddressLine2("ALine2");
			branchAdminModel.setCity("City");
			branchAdminModel.setState("State");
			branchAdminModel.setZipCode(102150);
			branchAdminModel.setBranchAdminId("branch29");
			MockHttpSession session=new MockHttpSession();
			MockHttpServletRequest request=new MockHttpServletRequest();
				ModelAndView mv=adminController.createBranchAdmin(branchAdminModel, errors, request);
		 String res=mv.getViewName();
		 String actual="createbranchadmin";
		 
		 assertEquals(res,actual);
	}catch(Exception e){
		
		}
	}
	@Test
	public void testGetRegisteration() {
		String mv=adminController.getRegisteration();
		
		
		String expected="register";
		
		assertEquals(mv,expected);
	}
	
	

	
	
@Test
	public void testUpdateBranchAdmin() {
		
	 BranchAdminModel branchAdminModel=new BranchAdminModel();
	 
		branchAdminModel.setBranchAdminFirstName("sad");
		branchAdminModel.setBranchAdminLastName("mad");
		branchAdminModel.setBranchAdminAge(55);
		branchAdminModel.setBranchAdminGender("M");
		branchAdminModel.setBranchAdminDOB("45/8/12");
		branchAdminModel.setBranchAdminContactNo("80258963");
		branchAdminModel.setBranchAdminAltContactNo("152630879");
		branchAdminModel.setBranchAdminEmailId("admin@gmail.com");
		branchAdminModel.setBranchName("Bname");
		branchAdminModel.setAddressLine1("ALine1");
		branchAdminModel.setAddressLine2("ALine2");
		branchAdminModel.setCity("City");
		branchAdminModel.setState("State");
		branchAdminModel.setZipCode(102102);
		branchAdminModel.setBranchAdminId("branch29");
		
		MockHttpSession session=new MockHttpSession();
		MockHttpServletRequest request=new MockHttpServletRequest();
		request.setSession(session);
		session.setAttribute("adminId","1");
		ModelAndView mv=adminController.updateBranchAdmin(branchAdminModel,request);
		String actual="branchadmin";
		String expected=mv.getViewName();
		assertEquals(actual,expected);
	}
	
	@Test
	public void testGetallMedicines() {
		MockHttpSession session=new MockHttpSession();
		MockHttpServletRequest request=new MockHttpServletRequest();
		request.setSession(session);
		session.setAttribute("adminId","1");
		ModelAndView mv=adminController.getallMedicines(request);
		String actual=mv.getViewName();
		String expected="allmedicines";
		assertEquals(actual,expected);
	
	}
	
	

	

	

	
}
