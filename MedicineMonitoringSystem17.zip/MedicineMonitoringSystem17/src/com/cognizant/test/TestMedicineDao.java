package com.cognizant.test;

import static org.junit.Assert.*;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import com.cognizant.dao.MedicineDAOImpl;
import com.cognizant.entity.Medicine;
import com.cognizant.helper.SessionCreator;


@ContextConfiguration(locations="classpath:/config/applicationContext.xml")
public class TestMedicineDao {

	
	private SessionCreator sessionCreator;
	
	@Mock
	private ApplicationContext ioc;
	@Mock
	private SessionCreator mockedSessionCreator;
	@Mock
	private Session mockedSession;
	@Mock
	private Transaction mockedTransaction;
	@Mock
	private Query mockedQuery;
	@Mock
	private List<Medicine> mockedMedicineList;
	@Spy
	private Medicine medicine;

	@InjectMocks

	private MedicineDAOImpl medicineDaoImpl;
	
	
	private MedicineDAOImpl medicineDaoImpl1;

	@Before
	public void setUp() throws Exception {
		 MockitoAnnotations.initMocks(this);

		 ApplicationContext ioc= new ClassPathXmlApplicationContext("config/applicationContext.xml");
	   	sessionCreator=(SessionCreator)ioc.getBean("sessionCreator");
	    medicineDaoImpl.setSessionCreator(this.sessionCreator);
	    Mockito.when(mockedSessionCreator.sessionCreator()).thenReturn(mockedSession);
	    Mockito.when(mockedSession.beginTransaction()).thenReturn(mockedTransaction);
	    Mockito.when(mockedSession.createQuery("from Medicine")).thenReturn(mockedQuery);
	    Mockito.when(mockedQuery.list()).thenReturn(mockedMedicineList); 

	   medicineDaoImpl1=Mockito.spy(medicineDaoImpl);
	   mockedMedicineList=Mockito.spy(medicineDaoImpl.getAllMedicines());
	 
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {		
	//	fail("something is wrong");
		assertEquals(true,mockedMedicineList.size()>0);
	}

}
