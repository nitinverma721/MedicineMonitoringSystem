package com.cognizant.exception;

public class AdminException extends RuntimeException {
	private String message;

	public AdminException(String message) {
		// TODO Auto-generated constructor stub
		this.message=message;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
