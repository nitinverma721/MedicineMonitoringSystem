package com.cognizant.exception;

public class RequestException extends RuntimeException{

	public RequestException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
