package com.cognizant.exception;

public class MedicineException extends RuntimeException {
	private String message;
	public MedicineException(String message) {
		super(message);
	}
	public String getMessage() {
		return this.message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
