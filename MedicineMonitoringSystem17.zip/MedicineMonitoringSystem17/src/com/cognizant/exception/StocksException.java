package com.cognizant.exception;

public class StocksException extends RuntimeException{

	public StocksException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
