package com.cognizant.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.exception.AdminException;
import com.cognizant.exception.BranchAdminException;
import com.cognizant.exception.MedicineException;
import com.cognizant.exception.SpringException;
import com.cognizant.model.AdminModel;
import com.cognizant.model.BranchAdminModel;
import com.cognizant.model.MedicineModel;
import com.cognizant.model.MedicineRequestModel;
import com.cognizant.service.AdminService;
import com.cognizant.service.BranchAdminService;
import com.cognizant.service.MedicineRequestService;
import com.cognizant.service.MedicineService;
import com.cognizant.service.NotificationService;


@Controller
@SessionAttributes({"branchAdminUpdate","medicineRequest","updateMedicine","pendingCount"})
public class AdminController {
	private static final Logger logger=LoggerFactory.getLogger(AdminController.class);

	public AdminController(){}
	@Autowired
	private AdminService adminLoginService;
	
	@Autowired @Qualifier("AddMedicineValidator")
	private Validator addmedicineValidator;
	
	@Autowired
	private MedicineService medicineService;
	
	
	@Autowired
	private BranchAdminService branchAdminService;
	
	@Autowired
	private MedicineRequestService medicineRequestService;
	
	@Autowired
	private NotificationService notificationService;
	
	
	@Autowired@Qualifier("LoginValidator")
	private Validator loginValidator;
	
	@Autowired@Qualifier("RegisterValidator")
	private Validator registerValidator;
	
	@Autowired@Qualifier("BranchAdminValidator")
	private Validator branchAdminValidator;
	
	
	//---------------ADMIN LOGIN AND REGISTERATION SECTION------------------------------------------------------------------
	
	//--------------This method is to dologin of admin---------------------------------------------------------------------
	@RequestMapping(value="loginadmin.htm",method=RequestMethod.POST)
	public ModelAndView loginAdmin(@ModelAttribute("admin") AdminModel admin,Errors errors,HttpSession session){
		logger.info("In Admin Login Method");
		
		ModelAndView mv=new ModelAndView();
		
		ValidationUtils.invokeValidator(loginValidator,admin,errors);
		if(errors.hasErrors()){
			mv.setViewName("adminlogin");
			logger.info("Login Error..");
		}
		else{
			//HttpSession session=request.getSession(true);
			session.setAttribute("adminId",admin.getAdminId());
			List<BranchAdminModel> branchAdminList=branchAdminService.getBranchAdminDetails();
			if(branchAdminList.isEmpty()){
				logger.info("------IF BRANCHADMIN LIST IS EMPTY in admin controller----------");
				throw new BranchAdminException("details are not available");
			}
			mv.addObject("branchAdminList",branchAdminList); 
			mv.setViewName("branchadmin");
			logger.info("Login Successful..");
		}
		return mv;
	}
	
//---------------------this method for 	showing login page of admin----------------------------
	@RequestMapping(value="index.htm",method=RequestMethod.GET)
	public String showLogin(){
		logger.info("redirect to Admin Login page..");
		return "adminlogin";
	}

	//---------this method to initialise admin object-----------------------------------------------
	@ModelAttribute("admin")
	public AdminModel createAdminModelObject(){
		logger.info("------In Admin modelattribute Method in admin controller----------");
		AdminModel adminModel=new AdminModel();
		return adminModel;
		
	}
	//-------------this method is to add new admin in database--------------------------------------
	@RequestMapping(value="registerUser.htm",method=RequestMethod.POST)
	public ModelAndView registerAdmin(@ModelAttribute("admin") AdminModel admin,Errors errors) {
		logger.info("------In REGISTER Admin in admin controller----------");
		ValidationUtils.invokeValidator(registerValidator, admin, errors);
		ModelAndView mv=new ModelAndView();
				
		if(errors.hasErrors()){
			logger.info("------In ERROR IN REGISTER Admin  Method in admin controller----------");
			mv.setViewName("register");
		}
		else{
			logger.info("------In REGISTRATION SUCCESSFUL  in admin controller----------");
			mv.setViewName("registersuccess");
		}
		return mv;	
	}
	//------------this method shows REGISTRATION PAGE FOR ADMIN--------------------------------
	@RequestMapping(value="register.htm",method=RequestMethod.POST)
	public String getRegisteration(){
		logger.info("------In showing REGISTRATION in admin controller----------");
		return "register";
		
	}
	//------------BRANCHADMIN SECTION----------------------------------------------------------
	
	//------------THIS METHOD SHOWS THE EXISTING BRANCHADMINS IN THE DATABASE--------------------------  
	@RequestMapping(value="showbranchadminpage.htm",method=RequestMethod.GET)
	@ExceptionHandler(AdminException.class)
	public ModelAndView showBranchAdminHome(HttpServletRequest request){
		
		logger.info("------In showing EXISTING BRANCHADMIN LIST in admin controller----------");
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
	
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
		
		}
		else
		{
		List<BranchAdminModel> branchAdminList=branchAdminService.getBranchAdminDetails();
		if(branchAdminList.isEmpty()){
			logger.info("------IF BRANCHADMIN LIST IS EMPTY in admin controller----------");
			throw new AdminException("Branch Admins doesn't exist");
		}
		mv.addObject("branchAdminList",branchAdminList); 
		mv.setViewName("branchadmin");
		}
		return mv;
	}
	
	
	//-------------THIS METHOD GETS BRANCHADMINS ID WRT BRANCHADMINID-------------------------------------

	
	@RequestMapping(value="branchAdminDetails.htm",method=RequestMethod.GET)
	@ExceptionHandler(BranchAdminException.class)
	public ModelAndView showBranchAdminDetails(@RequestParam("branchAdminId")String branchAdminId,ModelMap map,HttpServletRequest request){
		
		logger.info("------GETTING BRANCHADMINS OBJECT in admin controller----------");
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		session.setAttribute("adminId","1");
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		else
		{
		if(branchAdminId==null){
			logger.info("------IF BRANCHADMIN ID IS EMPTY in admin controller----------");
			throw new BranchAdminException("Some thing Went Wrong ");
		}
		
		BranchAdminModel branchAdmin=branchAdminService.getBranchAdminInfo(branchAdminId);
		map.addAttribute("branchAdminUpdate",branchAdmin);
		mv.setViewName("branchadmindetails");
		}
		return mv;
	}
	
	//-----THIS METHOD SHOWS ADD BRANCHADMIN PAGE--------------------------------------------------------
	@RequestMapping(value="createbranchadmin.htm",method=RequestMethod.GET)
	public ModelAndView showCreateBranchAdmin(HttpServletRequest request){
		logger.info("------SHOW ADD BRANCHADMIN PAGE in admin controller----------");
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		mv.setViewName("createbranchadmin");
		return mv;
		
	}
	
	//-------------THIS METHOD USED TO INITIALISE BRANCHADMIN------------------------------------------------
	@ModelAttribute("branchadmin")
	public BranchAdminModel createBranchAdminModelObject(){
		logger.info("------INITIALISE BRANCHADMIN in admin controller----------");
		BranchAdminModel branchAdminModel=new BranchAdminModel();
		return branchAdminModel;
		
	}
	
	//---------------THIS METHOD IS TO ADD NEW BRANCH ADMIN IN DATABASE-----------------------------------------
	@RequestMapping(value="registerbranchadmin.htm",method=RequestMethod.POST)
	@ExceptionHandler(BranchAdminException.class)
	public ModelAndView createBranchAdmin(@ModelAttribute("branchadmin") BranchAdminModel branchAdmin,Errors errors,HttpServletRequest request) {
		logger.info("------ADD NEW  BRANCHADMIN IN DATABASE in admin controller----------");

		
		
		
			
		ValidationUtils.invokeValidator(branchAdminValidator, branchAdmin, errors);
		ModelAndView mv=new ModelAndView();
	
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		
		if(errors.hasErrors()){
			
			logger.info("------IF ERROR IN ADDING BRANCHADMIN  in admin controller----------");
			mv.setViewName("createbranchadmin");
		}
		else{
			logger.info("------IF BRANCHADMIN ADDED SUCCCESSFULLY EMPTY in admin controller----------");
			List<BranchAdminModel> branchAdminList=branchAdminService.getBranchAdminDetails();
			if(branchAdminList.isEmpty()){
				logger.info("------IF BRANCHADMIN LIST IS EMPTY in admin controller----------");
				throw new BranchAdminException("details are not available");
			}
			mv.addObject("branchAdminList",branchAdminList); 
			mv.setViewName("branchadmin");

		}		
		return mv;	
	}
	
	//--------THIS METHOD TO SHOW UPDATE BRANCHADMIN PAGE--------------------------------------
	
	@RequestMapping(value="showUpdateBranchAdminPage.htm",method=RequestMethod.GET)
	public ModelAndView showUpdateBranchAdminPage(HttpServletRequest request){
		logger.info("------SHOW UPDATE BRANCHADMIN PAGE in admin controller----------");
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		mv.setViewName("updatebranchadmin");
		return mv;
		
	}
	
	//-------------THIS METHOD TO UPDATE BRANCH ADMIN IN DATABASE-----------------------------------------
	@RequestMapping(value="updatebranchadmin.htm",method=RequestMethod.POST)
	@ExceptionHandler(BranchAdminException.class)
	public ModelAndView updateBranchAdmin(@ModelAttribute("branchadminUpdate") BranchAdminModel branchAdmin,HttpServletRequest request) {
		ModelAndView mv=new ModelAndView();
		logger.info("------UPDATE BRANCHADMIN  in admin controller----------");
		boolean res=branchAdminService.updateBranchAdminDetails(branchAdmin);
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		else
		{
		if(res==true)
		{
			logger.info("------IF BRANCHADMIN  ADDED in admin controller----------");
			List<BranchAdminModel> branchAdminList=branchAdminService.getBranchAdminDetails();
			if(branchAdminList.isEmpty()){
				logger.info("------IF BRANCHADMIN LIST IS EMPTY in admin controller----------");
				throw new BranchAdminException("Details not found, Some thing went Wrong");
			}
			mv.addObject("branchAdminList",branchAdminList); 
			mv.setViewName("branchadmin");

		}
		
		else
		{logger.info("------IF BRANCHADMIN DONOT ADDED in admin controller----------");
			mv.setViewName("updatebranchadmin");
		}
		}
		return mv;	
	}
	
	
			
	
	
	
	//-----------------------BRANCHADMIN REQUEST SECTION------------------------------------------
	//-----------TO INITIALISE REQUEST ---------------------------------------------------------

	@ModelAttribute("medicinerequest")
	public MedicineRequestModel createMedicineRequestModelObject(){	
		logger.info("------INITIALISE REQUEST in admin controller----------");
		MedicineRequestModel requestModel=new MedicineRequestModel();
		return requestModel;	
	}
	
	//-----------TO SHOW ADDREQUEST PAGE---------------------------------------------------------
	@RequestMapping(value="showcreaterequestpage.htm",method=RequestMethod.GET)
	@ExceptionHandler(MedicineException.class)
	public ModelAndView showCreateRequestMedicinepage(HttpServletRequest request){
		
		logger.info("------SHOW ADD REQUEST PAGE in admin controller----------");
		
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		List<String> branchAdminIdList=medicineRequestService.getBranchAdminIds();
		List<Integer> medicineIdList=medicineRequestService.getMedicineIds();
		if(medicineIdList.isEmpty()){
			logger.info("------IF MEDICINE LIST IS EMPTY in admin controller----------");
			throw new MedicineException("Something went wrong,Please try again");
		}
		
		mv.addObject("branchAdminIdList",branchAdminIdList);
		mv.addObject("medicineIdList",medicineIdList);
		mv.setViewName("createrequest");
		return mv;
	}
	
	//---------------THIS METHOD ADDS REQUEST IN DATABASE----------------------------------------------------------
	@RequestMapping(value="createmedicinerequest.htm",method=RequestMethod.POST)
	
	public ModelAndView createMedicineRequest(@ModelAttribute("medicinerequest") MedicineRequestModel medicineRequest,ModelMap map,HttpServletRequest request) {
		ModelAndView mv=new ModelAndView();
		logger.info("------ADDS REQUEST IN DB in admin controller----------");
		medicineRequest.setAdminResponse("P");
		boolean res=medicineRequestService.insertMedicineRequest(medicineRequest);
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		else
		{
			if(res==true)
				{	logger.info("------IF REQUEST ADDED in admin controller----------");
					List<MedicineRequestModel> medicineRequestList=medicineRequestService.getMedicineRequests();
					int pendingRequests=NotificationService.pendingRequestsCount;
					map.addAttribute("pendingCount",pendingRequests);
					mv.addObject("medicineRequestList",medicineRequestList); 
					mv.setViewName("showmedicinerequests");
				}
			else{
				
		
					logger.info("------IF REQUEST FAILS in admin controller----------");
					mv.setViewName("createrequest");
			}
		}
		return mv;	
	}
	
	//-----------------SHOWS ALL MEDICINS FROM DB-----------------------------------------------------------------
	@RequestMapping(value="showmedicinerequests.htm",method=RequestMethod.GET)
	public ModelAndView showMedicineRequests(ModelMap map,HttpServletRequest request){
		logger.info("------SHOWS ALL REQUEST FROM DB in admin controller----------");
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		List<MedicineRequestModel> medicineRequestList=medicineRequestService.getMedicineRequests();
		mv.addObject("medicineRequestList",medicineRequestList);
		notificationService.checkPendingRequests();
		int pendingRequests=NotificationService.pendingRequestsCount;
		map.addAttribute("pendingCount",pendingRequests);

		mv.setViewName("showmedicinerequests");
		return mv;
	}
	
	/*-----------------
	@RequestMapping(value="showapprovedrequests.htm",method=RequestMethod.GET)
	public ModelAndView showMedicineAprovedRequests(){
		ModelAndView mv=new ModelAndView();
		List<MedicineRequestModel> medicineRequestList=medicineRequestService.getApprovedRequests();
		mv.addObject("approvedList",medicineRequestList);
		mv.setViewName("approvedrequests");
		return mv;
	}
	
	@RequestMapping(value="showrejectedrequests.htm",method=RequestMethod.GET)
	public ModelAndView showRejectedRequests(ModelMap map){
		ModelAndView mv=new ModelAndView();
		List<MedicineRequestModel> medicineRequestList=medicineRequestService.getRejectedRequests();
		mv.addObject("rejectedList",medicineRequestList);
		mv.setViewName("rejectrequests");
		return mv;
	}
	*/
	
	//-----------GETS REQUEST OBJECT WITH REQUESTID------------------------------------------------------
	@RequestMapping(value="updatestatusrequest.htm",method=RequestMethod.GET)
	public ModelAndView updateMedicineRequestsStatus(@RequestParam("requestId") int requestId,ModelMap map,HttpServletRequest request){
		logger.info("------GETTING REQUEST OBJECT in admin controller----------");
		ModelAndView mv=new ModelAndView();
		MedicineRequestModel medicineRequest=medicineRequestService.fetchMedicineRequestInfo(requestId);
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		map.addAttribute("medicineRequest",medicineRequest); 
		mv.setViewName("medicinerequestupdate");
		return mv;
	}
	
	//------------------APPROVE REQUEST IN DB------------------------------------------------------------------
	@RequestMapping(value="approvestatusrequest.htm",method=RequestMethod.POST)
	@ExceptionHandler(MedicineException.class)
	public ModelAndView approveMedicineRequestsStatus(@ModelAttribute("medicineRequest")MedicineRequestModel medicineRequest,ModelMap map,HttpServletRequest request){
		medicineRequest.setAdminResponse("A");
		logger.info("------IN APPROVE REQUEST  in admin controller----------");
		if(medicineRequest.getBranchAdminId()==null){
			logger.info("------IF BRANCHADMINID IS NULL in admin controller----------");
			throw new MedicineException("Branch Admin Id is Invalid here");
		}
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		if(medicineRequestService.checkMedicineRequest(medicineRequest)){
			logger.info("------IF REQUEST IS RIGHT in admin controller----------");
			if(medicineRequestService.updateBranchAdminRequest(medicineRequest))
			{logger.info("------IF REQUEST IS UPDATED in admin controller----------");
				List<MedicineRequestModel> medicineRequestList=medicineRequestService.getMedicineRequests();
			
				
				int pendingRequests=NotificationService.pendingRequestsCount;
				map.addAttribute("pendingCount",pendingRequests);
			
				mv.addObject("medicineRequestList",medicineRequestList); 
				mv.setViewName("showmedicinerequests");
			}
			else {
				logger.info("------IF REQUEST IS NOT UPDATED in admin controller----------");
				mv.setViewName("medicinerequestupdate");
			}
		}
		else {
			logger.info("------IF REQUEST QUANTIY IS NOT APPROPRIATE in admin controller----------");
			mv.addObject("message","stocks are not available");
		
			mv.setViewName("medicinerequestupdate");
		}
		
		return mv;
	}
	//---------------REJECTS REQUEST IN DB------------------------------------------------------------------------------
	@RequestMapping(value="rejectstatusrequest.htm",method=RequestMethod.POST)
	public ModelAndView rejectMedicineRequestsStatus(@ModelAttribute("medicineRequest")MedicineRequestModel medicineRequest,ModelMap map,HttpServletRequest request){
		medicineRequest.setAdminResponse("R");
		logger.info("------REJECTING  REQUEST in admin controller----------");
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
		if(medicineRequestService.updateBranchAdminRequest(medicineRequest))
		{logger.info("------IF REQUEST IS REJECTED SUCCESSFULLY in admin controller----------");
			List<MedicineRequestModel> medicineRequestList=medicineRequestService.getMedicineRequests();
			notificationService.checkPendingRequests();
			int pendingRequests=NotificationService.pendingRequestsCount;
			map.addAttribute("pendingCount",pendingRequests);
	
			mv.addObject("medicineRequestList",medicineRequestList); 
			mv.setViewName("showmedicinerequests");
		}
		else {
			logger.info("------IF REQUEST IS NOT REJECTED SUCCESSFULLY in admin controller----------");
			mv.setViewName("medicinerequestupdate");
		}
		
		return mv;
	}
	
	//---------------------------------------------------------------------------------------------------
	
	
	//Method to redirect to All Medicines Description Page 
	@RequestMapping(value="medicines.htm",method=RequestMethod.GET)
	@ExceptionHandler(MedicineException.class)
	public ModelAndView getallMedicines(HttpServletRequest request){
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
	
		if(session.getAttribute("adminId")==null){
			mv.setViewName("adminlogin");
			return mv;
		}
			List<MedicineModel> medList=medicineService.getAllMedicines();
				if(medList.isEmpty()){
					throw new MedicineException("Please try again later");
				}
			mv.addObject("medList", medList);
			mv.setViewName("allmedicines");
		
		return mv;
		
	}
		//Method to Store All the Data which user has entered 

		
		@RequestMapping(value="addMedicineData.htm",method=RequestMethod.GET)
		@ExceptionHandler({SpringException.class})
		public ModelAndView addMedicine(@ModelAttribute ("medicine") MedicineModel medicine,Errors errors,HttpServletRequest request){
					
			if(medicine.getDosage()>1000){
				System.out.println(medicine.getDosage());
				logger.info("------Dosage too high for usage-----");
				System.out.println("------Dosage too high for usage-----");
				throw new SpringException("Dosage is very High,can't except dangerous Medicines");
			}
			
			
			ValidationUtils.invokeValidator(addmedicineValidator, medicine, errors);
		
			
				ModelAndView mv=new ModelAndView();
			
				HttpSession session = request.getSession(false);
				if(session.getAttribute("adminId")==null){
					mv.setViewName("adminlogin");
					return mv;
				}
					if(errors.hasErrors()){
						mv.setViewName("addmedicines");
					}
					else{
						List<MedicineModel> medList=medicineService.getAllMedicines();
						
						mv.addObject("medList", medList);
						mv.setViewName("allmedicines");
					}
			return mv;
		}
		
		//----------------------------------------------------------------------------------------------	
		//Method to Redirect to Add Medicine Page
		
		
		@RequestMapping(value="addMedicine.htm",method=RequestMethod.GET)
		public String addMedicine(){
		//	logger.info("*****sayHello method call");
			return "addmedicines";
		}
		
		//----------------------------------------------------------------------------------------------
		//Method to redirect to medicine Quantity Update Page
		
		
		@RequestMapping(value="updatestockhere.htm",method=RequestMethod.GET)
		public ModelAndView updateMedicineStock(@RequestParam("MedicineId") String medicineId,ModelMap map,HttpServletRequest request){
			ModelAndView mv=new ModelAndView();
			HttpSession session = request.getSession(false);
			if(session.getAttribute("adminId")==null){
				mv.setViewName("adminlogin");
				
			}
			else
			{
			MedicineModel medicineObj=medicineService.retrieveMedicine(medicineId);
			map.addAttribute("updateMedicine",medicineObj);
			mv.setViewName("medicinequantityupdate");
			}
			return mv;
		
		}
		
		//----------------------------------------------------------------------------------------------
		//Method to update the values of a Existing value in DB
		
		
		@RequestMapping(value="medicinedetails.htm",method=RequestMethod.GET)
		public ModelAndView retrieveMedicineDetails(@RequestParam("MedicineId") String medicineId,ModelMap map,HttpServletRequest request){
		//	logger.info("*****sayHello method call");
			ModelAndView mv=new ModelAndView();
			HttpSession session = request.getSession(false);
			if(session.getAttribute("adminId")==null){
				mv.setViewName("adminlogin");
				return mv;
			}
			MedicineModel medicineObj=medicineService.retrieveMedicine(medicineId);
			map.addAttribute("updateMedicine",medicineObj);
			mv.setViewName("medicinedetails");
			return mv;
		}
		
		
		//----------------------------------------------------------------------------------------------
		//Method for creating Medicine's object for injecting it in View
		
		
		@ModelAttribute("medicine")
		public MedicineModel createMedicineModelObject(){
				
			MedicineModel mediCineModel=new MedicineModel();
			return mediCineModel;
			
		}
		
		//----------------------------------------------------------------------------------------------
		//Method to redirect to Stock Updation Page
		
		
		@RequestMapping(value="updateStock.htm",method=RequestMethod.GET)
		@ExceptionHandler(MedicineException.class)
		public ModelAndView updateStocks(HttpServletRequest request){
			ModelAndView mv=new ModelAndView();
			HttpSession session = request.getSession(false);
			if(session.getAttribute("adminId")==null){
				mv.setViewName("adminlogin");
				return mv;
			}
			List<MedicineModel> stockList=medicineService.getStockList();
			if(stockList.isEmpty()){
				throw new MedicineException("Something went wrong with the DB Connection");
			}
			mv.addObject("stockList", stockList);
			mv.setViewName("updatemedicinestock");
			return mv;
		}
		
		//----------------------------------------------------------------------------------------------
		//Method to redirect to the jsp page where we can update Medicine
		
		
		
		@RequestMapping(value="updateMedicine.htm",method=RequestMethod.GET)
		public ModelAndView updateMedicineData(HttpServletRequest request){
			ModelAndView mv=new ModelAndView();
			HttpSession session = request.getSession(false);
			if(session.getAttribute("adminId")==null){
				mv.setViewName("adminlogin");
				return mv;
			}
			
			mv.setViewName("updatemedicine");
			return mv;
			}
		
		//----------------------------------------------------------------------------------------------
		//Method to Persist the new object or updated object into DB with updated Quantity
		
		@RequestMapping(value="updatemedicinequantity1.htm",method=RequestMethod.POST)
		public ModelAndView updateMedicinequantity(@ModelAttribute ("updateMedicine") MedicineModel medicine,HttpServletRequest request){
					ModelAndView mv=new ModelAndView();
					
					HttpSession session = request.getSession(false);
					if(session.getAttribute("adminId")==null){
						mv.setViewName("adminlogin");
						return mv;
					}
					boolean result=medicineService.updateMedicineQuantity(medicine);
					if(result==true){
						List<MedicineModel> stockList=medicineService.getStockList();
						mv.addObject("stockList", stockList);
						mv.setViewName("updatemedicinestock");
					}
					else{
						mv.setViewName("medicinequantityupdate");
					}
			return mv;
		}
		
		//----------------------------------------------------------------------------------------------
		//Method to update Existing Medicine's Data
		
		
		@RequestMapping(value="updatemedicinedata.htm",method=RequestMethod.POST)
		@ExceptionHandler(MedicineException.class)
		public ModelAndView updateMedicine(@ModelAttribute ("medicine") MedicineModel medicine,HttpServletRequest request){
					ModelAndView mv=new ModelAndView();
					HttpSession session = request.getSession(false);
					if(session.getAttribute("adminId")==null){
						mv.setViewName("adminlogin");
						return mv;
					}
					if(medicine.getDosage()>1000){
						throw new MedicineException("Dosage is very High, can't except dangerous medicines");
					}
					boolean result=medicineService.updateMedicine(medicine);
					if(result==true){
						List<MedicineModel> medList=medicineService.getAllMedicines();
						
						mv.addObject("medList", medList);
						mv.setViewName("allmedicines");
					}
					else{
						mv.setViewName("updatemedicine");
					}
			return mv;
		}
		
		//----------------------------------------------------------------------------------------------
		//Method to Logout Existing User and Session.
				
		@RequestMapping(value="logoutadmin.htm",method=RequestMethod.GET)
					public String logout(HttpServletRequest request){
					HttpSession session = request.getSession(false);
					session.removeAttribute("adminId");
					session.invalidate();
					return "adminlogin";
		}
}
